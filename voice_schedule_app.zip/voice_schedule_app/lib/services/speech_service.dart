import 'package:speech_to_text/speech_to_text.dart' as stt;

enum SpeechState { idle, listening, notListening, error }

/// Wrapper tipis di atas package speech_to_text, locale dikunci ke id_ID
/// (section 29). UI (voice_screen.dart) yang mengatur state machine
/// LISTENING -> TRANSCRIBING -> dst; service ini hanya expose STT mentah.
class SpeechService {
  SpeechService._internal();
  static final SpeechService instance = SpeechService._internal();

  final stt.SpeechToText _speech = stt.SpeechToText();
  bool _available = false;

  Future<bool> init() async {
    _available = await _speech.initialize(
      onError: (_) {},
      onStatus: (_) {},
    );
    return _available;
  }

  bool get isAvailable => _available;
  bool get isListening => _speech.isListening;

  /// Mulai mendengarkan. [onResult] dipanggil tiap ada update transkripsi
  /// (termasuk partial result, supaya UI bisa tampilkan teks berjalan).
  /// [onSoundLevel] opsional, dipakai untuk animasi waveform di voice_screen.
  Future<void> startListening({
    required void Function(String text, bool isFinal) onResult,
    void Function(double level)? onSoundLevel,
  }) async {
    if (!_available) {
      final ok = await init();
      if (!ok) return;
    }
    await _speech.listen(
      localeId: 'id_ID',
      onResult: (result) {
        onResult(result.recognizedWords, result.finalResult);
      },
      onSoundLevelChange: onSoundLevel,
      listenOptions: stt.SpeechListenOptions(
        partialResults: true,
        cancelOnError: true,
      ),
    );
  }

  Future<void> stopListening() async {
    if (_speech.isListening) {
      await _speech.stop();
    }
  }

  /// Dipanggil saat app kehilangan fokus / ada interupsi (section 39) —
  /// hentikan paksa tanpa menunggu hasil akhir.
  Future<void> cancel() async {
    if (_speech.isListening) {
      await _speech.cancel();
    }
  }
}
