import 'package:flutter_tts/flutter_tts.dart';

/// Wrapper tipis di atas flutter_tts, locale dikunci id-ID (section 30).
class TtsService {
  TtsService._internal() {
    _tts.setLanguage('id-ID');
    _tts.setSpeechRate(0.5);
  }
  static final TtsService instance = TtsService._internal();

  final FlutterTts _tts = FlutterTts();

  Future<void> speak(String text) async {
    if (text.trim().isEmpty) return;
    await _tts.stop(); // jangan tumpuk antrean kalau dipanggil beruntun
    await _tts.speak(text);
  }

  Future<void> stop() => _tts.stop();
}
