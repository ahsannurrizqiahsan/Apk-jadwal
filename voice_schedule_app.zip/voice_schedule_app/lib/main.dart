import 'dart:async';

import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';

import 'core/theme/app_theme.dart';
import 'data/repositories/settings_repository.dart';
import 'data/repositories/task_repository.dart';
import 'features/shell/app_shell.dart';
import 'services/ai_command_service.dart';
import 'services/notification_service.dart';
import 'services/reminder_scheduler.dart';

Future<void> main() async {
  // section 38 (Fast Launch): semua langkah di bawah murni lokal (database
  // SQLite, SharedPreferences, init plugin notifikasi) — tidak ada network
  // request sebelum UI pertama tampil.
  WidgetsFlutterBinding.ensureInitialized();

  final settings = SettingsRepository();
  await settings.load();

  await NotificationService.instance.init();

  final taskRepository = TaskRepository();
  final reminderScheduler = ReminderScheduler(repository: taskRepository);

  // AiCommandService tanpa remoteParser = sepenuhnya jalan dengan parser
  // lokal (section 33). Untuk mengaktifkan lapisan AI sungguhan (section 32),
  // injeksikan remoteParser di sini, contoh:
  //
  //   AiCommandService(
  //     remoteParser: (text, now) async {
  //       final apiKey = const String.fromEnvironment('ANTHROPIC_API_KEY');
  //       if (apiKey.isEmpty) return null; // fallback otomatis ke parser lokal
  //       // panggil LLM pilihanmu di sini, parse responsnya jadi ParsedCommand
  //       return null;
  //     },
  //   )
  //
  // API key TIDAK PERNAH hardcode di source (section 45) — selalu dari
  // --dart-define / file .env yang di-gitignore.
  final aiCommandService = AiCommandService();

  // section 28 (boot restore), bagian yang bisa dijalankan dari Dart:
  // setiap kali app dibuka, reminder aktif dijadwalkan ulang. Ini menutupi
  // skenario "user buka app lagi setelah HP restart". Untuk restore TANPA
  // perlu membuka app (true background boot restore), perlu BroadcastReceiver
  // native + workmanager — lihat catatan di reminder_scheduler.dart & README.
  unawaited(reminderScheduler.rescheduleAllActiveReminders());

  // Teruskan tap tombol aksi notifikasi (✅/⏰/🔕 — section 13) ke scheduler.
  NotificationService.instance.actionStream.listen(reminderScheduler.handleNotificationAction);

  // section 3: cek permission yang SUDAH ada, jangan minta di sini. Kalau
  // belum pernah diberikan, app mendarat di Home seperti biasa dan voice
  // mode akan memintanya saat pertama kali dipakai (section 44).
  final micAlreadyGranted = await Permission.microphone.status.isGranted;

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider<SettingsRepository>.value(value: settings),
        ChangeNotifierProvider<TaskRepository>.value(value: taskRepository),
        Provider<ReminderScheduler>.value(value: reminderScheduler),
        Provider<AiCommandService>.value(value: aiCommandService),
      ],
      child: VoiceScheduleApp(
        startInVoiceMode: settings.autoListenOnLaunch && micAlreadyGranted,
      ),
    ),
  );
}

class VoiceScheduleApp extends StatelessWidget {
  const VoiceScheduleApp({super.key, required this.startInVoiceMode});

  final bool startInVoiceMode;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Asisten Jadwal',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      darkTheme: AppTheme.dark(),
      themeMode: ThemeMode.system,
      home: AppShell(autoOpenVoice: startInVoiceMode),
    );
  }
}
