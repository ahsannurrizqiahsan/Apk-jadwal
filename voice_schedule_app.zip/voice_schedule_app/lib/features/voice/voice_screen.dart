import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../data/models/task_model.dart';
import '../../data/repositories/settings_repository.dart';
import '../../data/repositories/task_repository.dart';
import '../../services/ai_command_service.dart';
import '../../services/reminder_scheduler.dart';
import '../../services/speech_service.dart';
import '../../services/tts_service.dart';

enum VoiceUiState { listening, transcribing, thinking, needsClarification, executing, success, error }

/// Layar inti aplikasi (section 2, 22-24): begitu dibuka, mic langsung
/// listening. Menangani state machine penuh + orkestrasi ke
/// AiCommandService/TaskRepository/ReminderScheduler/TtsService, termasuk
/// follow-up percakapan sederhana (section 31).
class VoiceScreen extends StatefulWidget {
  const VoiceScreen({super.key});

  @override
  State<VoiceScreen> createState() => _VoiceScreenState();
}

class _VoiceScreenState extends State<VoiceScreen> with SingleTickerProviderStateMixin {
  final _speech = SpeechService.instance;
  final _tts = TtsService.instance;

  VoiceUiState _state = VoiceUiState.listening;
  String _transcript = '';
  String _statusText = 'Mendengarkan...';
  String? _errorText;
  TaskModel? _resultTask;
  double _soundLevel = 0;

  // Follow-up percakapan sederhana: satu pertanyaan tertunda sekaligus
  // (cukup untuk alur "Kapan?" / "Ingatkan setiap jam?" di section 31).
  String? _pendingClarification; // 'date' | 'hourly'
  String _accumulatedText = '';
  ParsedCommand? _pendingCreateCommand;

  late final AnimationController _pulseController;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))
      ..repeat(reverse: true);
    _startListening();
  }

  @override
  void dispose() {
    _pulseController.dispose();
    // section 39: interupsi (close paksa, kehilangan fokus) harus berhenti
    // dengan aman tanpa menyimpan data setengah jadi.
    _speech.cancel();
    super.dispose();
  }

  Future<void> _startListening() async {
    final inClarification = _pendingClarification != null;
    setState(() {
      _state = inClarification ? VoiceUiState.needsClarification : VoiceUiState.listening;
      if (!inClarification) _statusText = 'Mendengarkan...';
      _transcript = '';
    });
    final ok = await _speech.init();
    if (!ok) {
      if (!mounted) return;
      setState(() {
        _state = VoiceUiState.error;
        _errorText = 'Microphone tidak tersedia atau izin belum diberikan.';
      });
      return;
    }
    await _speech.startListening(
      onResult: (text, isFinal) {
        if (!mounted) return;
        setState(() => _transcript = text);
        if (isFinal && text.trim().isNotEmpty) {
          _onFinalTranscript(text);
        }
      },
      onSoundLevel: (level) {
        if (!mounted) return;
        setState(() => _soundLevel = level.clamp(0, 10));
      },
    );
  }

  Future<void> _onFinalTranscript(String text) async {
    await _speech.stopListening();
    if (!mounted) return;
    setState(() {
      _state = VoiceUiState.transcribing;
      _statusText = 'Memahami perintah...';
    });

    if (_pendingClarification != null) {
      await _handleClarificationAnswer(text);
      return;
    }

    _accumulatedText = text;
    await _processCommand(text);
  }

  Future<void> _processCommand(String text) async {
    if (!mounted) return;
    setState(() => _state = VoiceUiState.thinking);
    final ai = context.read<AiCommandService>();
    final command = await ai.parse(text);

    switch (command.intent) {
      case CommandIntent.createEvent:
      case CommandIntent.createTask:
      case CommandIntent.createNote:
        await _handleCreate(command);
        break;
      case CommandIntent.completeTask:
        await _handleComplete(command);
        break;
      case CommandIntent.deleteEvent:
        await _handleDelete(command);
        break;
      case CommandIntent.updateEvent:
        await _handleUpdate(command);
        break;
      case CommandIntent.enableReminder:
        await _handleToggleReminder(command, enable: true);
        break;
      case CommandIntent.disableReminder:
        await _handleToggleReminder(command, enable: false);
        break;
      case CommandIntent.getTodaySchedule:
        await _handleQuery(DateTime.now(), 'hari ini');
        break;
      case CommandIntent.getTomorrowSchedule:
        await _handleQuery(DateTime.now().add(const Duration(days: 1)), 'besok');
        break;
      case CommandIntent.getWeekSchedule:
        await _handleWeekQuery();
        break;
    }
  }

  Future<void> _handleCreate(ParsedCommand command) async {
    if (command.dateTime == null) {
      _askClarification('date', 'Kapan?');
      return;
    }

    final settings = context.read<SettingsRepository>();
    final isTask = command.intent == CommandIntent.createTask;
    var hourly = command.hourlyReminder;

    // section 11: tugas yang belum menyebut hourly reminder secara eksplisit
    // -> tanya singkat, kecuali default Settings sudah ON.
    if (isTask && !hourly && !settings.hourlyReminderDefault) {
      _askClarification('hourly', 'Ingatkan setiap jam?', pendingCommand: command);
      return;
    }
    if (isTask && !hourly && settings.hourlyReminderDefault) {
      hourly = true;
    }

    await _createAndSchedule(command, hourly: hourly);
  }

  Future<void> _createAndSchedule(ParsedCommand command, {required bool hourly}) async {
    if (!mounted) return;
    setState(() => _state = VoiceUiState.executing);
    final repo = context.read<TaskRepository>();
    final scheduler = context.read<ReminderScheduler>();
    final settings = context.read<SettingsRepository>();

    final dateTime = command.dateTime!;
    final type = switch (command.intent) {
      CommandIntent.createTask => TaskType.task,
      CommandIntent.createNote => TaskType.note,
      _ => TaskType.schedule,
    };

    final task = await repo.create(
      title: (command.title?.isNotEmpty ?? false) ? command.title! : command.rawText,
      date: DateTime(dateTime.year, dateTime.month, dateTime.day),
      time: command.hasExplicitTime ? dateTime : null,
      type: type,
      reminderEnabled: command.reminderOffset != null,
      reminderTime:
          command.reminderOffset != null ? dateTime.subtract(command.reminderOffset!) : null,
      hourlyReminder: hourly,
      hourlyStartTime: settings.activeHoursStart,
      hourlyEndTime: settings.activeHoursEnd,
    );

    if (hourly) {
      await scheduler.scheduleHourlyForTask(task);
    } else if (task.reminderEnabled) {
      await scheduler.scheduleSingleReminder(task);
    }

    final confirmation = hourly
        ? 'Baik. Saya akan mengingatkan kamu setiap jam untuk ${task.title}.'
        : '${task.title} berhasil dijadwalkan ${_speakDate(task.occursAt)}.';

    _finishWithSuccess(task: task, spokenConfirmation: confirmation);
  }

  Future<void> _handleComplete(ParsedCommand command) async {
    if (!mounted) return;
    setState(() => _state = VoiceUiState.executing);
    final repo = context.read<TaskRepository>();
    final scheduler = context.read<ReminderScheduler>();
    final keyword = (command.title?.isNotEmpty ?? false) ? command.title! : command.rawText;
    final matches = await repo.searchByTitle(keyword);

    if (matches.isEmpty) {
      _finishWithError('Saya tidak menemukan tugas "$keyword".');
      return;
    }
    // Scaffold: ambil match pertama. Menanyakan konfirmasi saat hasil lebih
    // dari satu adalah pekerjaan Phase berikutnya (section 18: "Jika ambigu,
    // tanyakan konfirmasi singkat").
    final task = matches.first;
    await repo.markCompleted(task.id);
    await scheduler.onTaskCompleted(task.id);
    _finishWithSuccess(task: task, spokenConfirmation: 'Baik. Tugas ${task.title} sudah ditandai selesai.');
  }

  Future<void> _handleDelete(ParsedCommand command) async {
    if (!mounted) return;
    setState(() => _state = VoiceUiState.executing);
    final repo = context.read<TaskRepository>();
    final scheduler = context.read<ReminderScheduler>();
    final keyword = (command.title?.isNotEmpty ?? false) ? command.title! : command.rawText;
    final matches = await repo.searchByTitle(keyword);
    if (matches.isEmpty) {
      _finishWithError('Saya tidak menemukan jadwal "$keyword".');
      return;
    }
    final task = matches.first;
    await scheduler.onTaskCompleted(task.id);
    await repo.delete(task.id);
    _finishWithSuccess(task: null, spokenConfirmation: '${task.title} sudah dihapus.');
  }

  Future<void> _handleUpdate(ParsedCommand command) async {
    if (!mounted) return;
    setState(() => _state = VoiceUiState.executing);
    final repo = context.read<TaskRepository>();
    final scheduler = context.read<ReminderScheduler>();
    final keyword = (command.title?.isNotEmpty ?? false) ? command.title! : command.rawText;
    final matches = await repo.searchByTitle(keyword);
    if (matches.isEmpty) {
      _finishWithError('Saya tidak menemukan "$keyword" untuk diubah.');
      return;
    }
    if (command.dateTime == null) {
      _finishWithError('Mau diubah jadi kapan? Coba ucapkan lagi dengan waktunya.');
      return;
    }
    final task = matches.first;
    final newDt = command.dateTime!;
    final updated = task.copyWith(
      date: DateTime(newDt.year, newDt.month, newDt.day),
      time: command.hasExplicitTime ? newDt : null,
      clearTime: !command.hasExplicitTime,
    );
    await repo.update(updated);
    if (updated.hourlyReminder) {
      await scheduler.scheduleHourlyForTask(updated);
    } else if (updated.reminderEnabled) {
      await scheduler.scheduleSingleReminder(updated);
    }
    _finishWithSuccess(
      task: updated,
      spokenConfirmation: '${updated.title} diubah jadi ${_speakDate(updated.occursAt)}.',
    );
  }

  Future<void> _handleToggleReminder(ParsedCommand command, {required bool enable}) async {
    if (!mounted) return;
    setState(() => _state = VoiceUiState.executing);
    final repo = context.read<TaskRepository>();
    final scheduler = context.read<ReminderScheduler>();
    final keyword = (command.title?.isNotEmpty ?? false) ? command.title! : command.rawText;
    final matches = await repo.searchByTitle(keyword);
    if (matches.isEmpty) {
      _finishWithError('Saya tidak menemukan "$keyword".');
      return;
    }
    final task = matches.first;
    if (enable) {
      final updated = task.copyWith(hourlyReminder: true);
      await repo.update(updated);
      await scheduler.scheduleHourlyForTask(updated);
      _finishWithSuccess(
        task: updated,
        spokenConfirmation: 'Pengingat setiap jam untuk ${updated.title} sudah diaktifkan.',
      );
    } else {
      await scheduler.stopReminderOnly(task.id);
      final updated = task.copyWith(hourlyReminder: false);
      await repo.update(updated);
      _finishWithSuccess(
        task: updated,
        spokenConfirmation: 'Reminder untuk ${updated.title} sudah dimatikan.',
      );
    }
  }

  Future<void> _handleQuery(DateTime date, String label) async {
    if (!mounted) return;
    setState(() => _state = VoiceUiState.executing);
    final repo = context.read<TaskRepository>();
    final items = await repo.getForDate(date);
    if (items.isEmpty) {
      _finishWithSuccess(task: null, spokenConfirmation: 'Kamu tidak punya kegiatan $label.');
      return;
    }
    final parts = items.map((t) {
      if (t.time == null) return t.title;
      final menit = t.time!.minute == 0 ? '' : ' ${t.time!.minute}';
      return '${t.title} pukul ${t.time!.hour}$menit';
    }).join(', ');
    _finishWithSuccess(
      task: null,
      spokenConfirmation: 'Kamu memiliki ${items.length} kegiatan $label: $parts.',
    );
  }

  Future<void> _handleWeekQuery() async {
    if (!mounted) return;
    setState(() => _state = VoiceUiState.executing);
    final repo = context.read<TaskRepository>();
    final now = DateTime.now();
    final items = <TaskModel>[];
    for (var i = 0; i < 7; i++) {
      items.addAll(await repo.getForDate(now.add(Duration(days: i))));
    }
    final pending = items.where((t) => t.status == TaskStatus.pending).toList();
    final spoken = pending.isEmpty
        ? 'Tidak ada tugas untuk minggu ini.'
        : 'Minggu ini ada ${pending.length} item: ${pending.map((t) => t.title).join(', ')}.';
    _finishWithSuccess(task: null, spokenConfirmation: spoken);
  }

  void _askClarification(String type, String question, {ParsedCommand? pendingCommand}) {
    _pendingClarification = type;
    _pendingCreateCommand = pendingCommand;
    setState(() {
      _state = VoiceUiState.needsClarification;
      _statusText = question;
    });
    _tts.speak(question);
    _startListening();
  }

  Future<void> _handleClarificationAnswer(String answer) async {
    final type = _pendingClarification;
    _pendingClarification = null;

    if (type == 'date') {
      final combined = '$_accumulatedText $answer';
      await _processCommand(combined);
      return;
    }
    if (type == 'hourly') {
      final yes = answer.toLowerCase().contains('ya') || answer.toLowerCase().contains('iya');
      final command = _pendingCreateCommand;
      _pendingCreateCommand = null;
      if (command != null) {
        await _createAndSchedule(command, hourly: yes);
      }
      return;
    }
  }

  void _finishWithSuccess({TaskModel? task, required String spokenConfirmation}) {
    if (!mounted) return;
    setState(() {
      _state = VoiceUiState.success;
      _statusText = spokenConfirmation;
      _resultTask = task;
    });
    final settings = context.read<SettingsRepository>();
    if (settings.voiceConfirmation) _tts.speak(spokenConfirmation);
  }

  void _finishWithError(String message) {
    if (!mounted) return;
    setState(() {
      _state = VoiceUiState.error;
      _errorText = message;
    });
    _tts.speak(message);
  }

  String _speakDate(DateTime dt) {
    final now = DateTime.now();
    final target = DateTime(dt.year, dt.month, dt.day);
    final today = DateTime(now.year, now.month, now.day);
    final diff = target.difference(today).inDays;
    final dayLabel = diff == 0 ? 'hari ini' : (diff == 1 ? 'besok' : '${dt.day}/${dt.month}');
    final timeLabel = '${dt.hour.toString().padLeft(2, '0')}.${dt.minute.toString().padLeft(2, '0')}';
    return '$dayLabel pukul $timeLabel';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Align(
              alignment: Alignment.topRight,
              child: IconButton(
                icon: const Icon(Icons.close_rounded),
                onPressed: () async {
                  await _speech.cancel();
                  if (context.mounted) Navigator.of(context).pop();
                },
              ),
            ),
            Expanded(
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 32),
                  child: _buildBody(context),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBody(BuildContext context) {
    switch (_state) {
      case VoiceUiState.success:
        return _SuccessView(
          task: _resultTask,
          message: _statusText,
          onDone: () => Navigator.of(context).maybePop(),
        );
      case VoiceUiState.error:
        return _ErrorView(message: _errorText ?? 'Terjadi kesalahan.', onRetry: _startListening);
      case VoiceUiState.thinking:
      case VoiceUiState.executing:
      case VoiceUiState.transcribing:
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(width: 48, height: 48, child: CircularProgressIndicator(strokeWidth: 3)),
            const SizedBox(height: 24),
            Text(_statusText, style: Theme.of(context).textTheme.titleMedium, textAlign: TextAlign.center),
          ],
        );
      case VoiceUiState.listening:
      case VoiceUiState.needsClarification:
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ScaleTransition(
              scale: Tween<double>(begin: 0.9, end: 1.1).animate(
                CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
              ),
              child: CircleAvatar(
                radius: 56,
                backgroundColor: Theme.of(context).colorScheme.primaryContainer,
                child: Icon(Icons.mic_rounded, size: 48, color: Theme.of(context).colorScheme.primary),
              ),
            ),
            const SizedBox(height: 20),
            _Waveform(level: _soundLevel),
            const SizedBox(height: 20),
            Text(_statusText, style: Theme.of(context).textTheme.titleMedium, textAlign: TextAlign.center),
            const SizedBox(height: 12),
            Text(
              _transcript.isEmpty ? ' ' : '"$_transcript"',
              style: Theme.of(context).textTheme.bodyLarge,
              textAlign: TextAlign.center,
            ),
          ],
        );
    }
  }
}

class _Waveform extends StatelessWidget {
  const _Waveform({required this.level});
  final double level;

  @override
  Widget build(BuildContext context) {
    final bars = List.generate(5, (i) {
      final h = (6.0 + (level * (i.isEven ? 1.4 : 2.2))).clamp(6.0, 36.0);
      return AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        width: 5,
        height: h,
        margin: const EdgeInsets.symmetric(horizontal: 2),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.primary,
          borderRadius: BorderRadius.circular(3),
        ),
      );
    });
    return Row(mainAxisAlignment: MainAxisAlignment.center, children: bars);
  }
}

class _SuccessView extends StatelessWidget {
  const _SuccessView({required this.task, required this.message, required this.onDone});
  final TaskModel? task;
  final String message;
  final VoidCallback onDone;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(Icons.check_circle_rounded, color: Theme.of(context).colorScheme.primary, size: 56),
        const SizedBox(height: 16),
        if (task != null) ...[
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(task!.title, style: Theme.of(context).textTheme.titleLarge),
                  const SizedBox(height: 8),
                  if (task!.time != null)
                    Text(
                      '🕖 ${task!.time!.hour.toString().padLeft(2, '0')}.${task!.time!.minute.toString().padLeft(2, '0')}',
                    ),
                  if (task!.hourlyReminder)
                    Text('🔁 Reminder setiap 1 jam · ${task!.hourlyStartTime}–${task!.hourlyEndTime}')
                  else if (task!.reminderEnabled)
                    const Text('🔔 Reminder aktif'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
        ],
        Text(message, textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodyLarge),
        const SizedBox(height: 24),
        FilledButton(onPressed: onDone, child: const Text('Selesai')),
      ],
    );
  }
}

class _ErrorView extends StatelessWidget {
  const _ErrorView({required this.message, required this.onRetry});
  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(Icons.error_outline_rounded, color: Theme.of(context).colorScheme.error, size: 48),
        const SizedBox(height: 16),
        Text(message, textAlign: TextAlign.center),
        const SizedBox(height: 20),
        FilledButton.icon(
          onPressed: onRetry,
          icon: const Icon(Icons.mic_rounded),
          label: const Text('Coba lagi'),
        ),
      ],
    );
  }
}
