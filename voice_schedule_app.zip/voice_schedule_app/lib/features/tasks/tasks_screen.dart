import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../data/models/task_model.dart';
import '../../data/repositories/task_repository.dart';
import '../../services/reminder_scheduler.dart';

class TasksScreen extends StatefulWidget {
  const TasksScreen({super.key});

  @override
  State<TasksScreen> createState() => _TasksScreenState();
}

class _TasksScreenState extends State<TasksScreen> {
  bool _showCompleted = false;

  @override
  Widget build(BuildContext context) {
    final repo = context.watch<TaskRepository>();

    return SafeArea(
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
            child: Row(
              children: [
                Expanded(
                  child: Text('Tugas', style: Theme.of(context).textTheme.headlineSmall),
                ),
                FilterChip(
                  label: const Text('Tampilkan selesai'),
                  selected: _showCompleted,
                  onSelected: (v) => setState(() => _showCompleted = v),
                ),
              ],
            ),
          ),
          Expanded(
            child: FutureBuilder<List<TaskModel>>(
              future: repo.getPending(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }
                final tasks = snapshot.data!.where((t) => t.type == TaskType.task).toList();
                if (tasks.isEmpty) {
                  return const Center(child: Text('Belum ada tugas.'));
                }
                return ListView.builder(
                  padding: const EdgeInsets.fromLTRB(20, 8, 20, 120),
                  itemCount: tasks.length,
                  itemBuilder: (context, i) => _TaskTile(task: tasks[i]),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _TaskTile extends StatelessWidget {
  const _TaskTile({required this.task});
  final TaskModel task;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: CheckboxListTile(
        value: task.status == TaskStatus.completed,
        controlAffinity: ListTileControlAffinity.leading,
        title: Text(task.title),
        subtitle: task.hourlyReminder
            ? Text('🔔 Setiap jam · ${task.hourlyStartTime}–${task.hourlyEndTime}')
            : (task.reminderEnabled ? const Text('🔔 Reminder aktif') : null),
        onChanged: (v) async {
          final repo = context.read<TaskRepository>();
          final scheduler = context.read<ReminderScheduler>();
          if (v == true) {
            await repo.markCompleted(task.id);
            await scheduler.onTaskCompleted(task.id);
          } else {
            await repo.update(task.copyWith(status: TaskStatus.pending, clearCompletedAt: true));
          }
        },
      ),
    );
  }
}
